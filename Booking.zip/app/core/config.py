# app/core/config.py
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field


class Settings(BaseSettings):
    # === Base de datos ===
    POSTGRES_HOST: str
    POSTGRES_PORT: int
    POSTGRES_DB: str
    POSTGRES_USER: str
    POSTGRES_PASSWORD: str

    # JWT / seguridad
    SECRET_KEY: str

    # Cadena completa de conexión (se arma en __init__)
    SQLALCHEMY_DATABASE_URI: str = Field(default="", init=False)

    # === Email / SMTP ===
    # Estos nombres mapean a variables de entorno:
    # EMAIL_USE_SSL, EMAIL_HOST, EMAIL_HOST_USER, EMAIL_HOST_PASSWORD, EMAIL_PORT, SMTP_FROM, SMTP_REPLY_TO
    email_use_ssl: bool = Field(default=True)                 # EMAIL_USE_SSL=true|false
    email_host: str = Field(default="smtp.hostinger.com")     # EMAIL_HOST
    email_host_user: str = Field(default="")                  # EMAIL_HOST_USER
    email_host_password: str = Field(default="")              # EMAIL_HOST_PASSWORD
    email_port: int = Field(default=465)                      # EMAIL_PORT
    smtp_from: str | None = Field(default=None)               # SMTP_FROM (opcional)
    smtp_reply_to: str | None = Field(default=None)           # SMTP_REPLY_TO (opcional)

    # Configuración de carga desde .env y comportamiento
    model_config = SettingsConfigDict(
        env_file=".env",
        env_prefix="",         # lee variables tal cual están en .env
        case_sensitive=False,  # EMAIL_HOST == email_host
        extra="ignore",        # ignora variables no declaradas (evita extra_forbidden)
    )

    def __init__(self, **data):
        super().__init__(**data)
        self.SQLALCHEMY_DATABASE_URI = (
            f"postgresql://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@"
            f"{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
        )


settings = Settings()
